import {Container, Typography} from '@mui/material';

export default function HomePage() {
  return (
    <Container sx={{mt: 8}}>
      <Typography variant="h4" align="center">
        Добро пожаловать в My Cloud!
      </Typography>
    </Container>
  );
}
