// Определяем тип окружения
const isDevelopment = import.meta.env.MODE === 'development';

// Базовый URL API
export const API_URL = isDevelopment 
  ? import.meta.env.VITE_API_URL 
  : '/api/v1';

// Другие конфигурационные параметры
export const CONFIG = {
  isDevelopment,
  apiUrl: API_URL,
  // Добавьте другие параметры конфигурации здесь
} as const;

// Типы для конфигурации
export type Config = typeof CONFIG;

