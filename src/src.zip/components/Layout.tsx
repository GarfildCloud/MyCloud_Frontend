import {AppBar, Toolbar, Typography, Button, Container} from '@mui/material';
import {Link, useNavigate, Outlet} from 'react-router-dom';
import {getAccessToken, logout} from '../services/auth';

export default function Layout() {
  const isLoggedIn = !!getAccessToken();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <>
      <AppBar position="static">
        <Toolbar>
          <Typography
            variant="h6"
            component={Link}
            to="/"
            sx={{flexGrow: 1, textDecoration: 'none', color: 'inherit'}}
          >
            My Cloud
          </Typography>

          {isLoggedIn ? (
            <Button color="inherit" onClick={handleLogout}>
              Выйти
            </Button>
          ) : (
            <>
              <Button color="inherit" component={Link} to="/login">
                Вход
              </Button>
              <Button color="inherit" component={Link} to="/register">
                Регистрация
              </Button>
            </>
          )}
        </Toolbar>
      </AppBar>

      <Container sx={{mt: 4}}>
        <Outlet/>
      </Container>
    </>
  );
}
