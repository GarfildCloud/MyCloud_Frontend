import { setUser } from '../store/userSlice';
import axios from 'axios';
import { API_URL } from '../config';

export async function login(username: string, password: string) {
  const response = await axios.post(`${API_URL}/users/token/`, {
    username,
    password,
  });

  const {access, refresh} = response.data;

  localStorage.setItem('access', access);
  localStorage.setItem('refresh', refresh);

  return response.data;
}

// ✅ Получение access-токена
export function getAccessToken(): string | null {
  return localStorage.getItem('access');
}

// ✅ Выход из системы
export function logout() {
  localStorage.removeItem('access');
  localStorage.removeItem('refresh');
}

export async function getCurrentUser(dispatch: any) {
  const token = localStorage.getItem('access');
  if (!token) throw new Error('Нет токена');

  const response = await axios.get(`${API_URL}/users/me/`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  // Сохраняем пользователя в Redux
  dispatch(setUser(response.data));

  return response.data; // ожидается { username, full_name, email, is_admin }
}

