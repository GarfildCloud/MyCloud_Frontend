import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface UserState {
  username: string | null;
  full_name: string | null;
  email: string | null;
  is_admin: boolean;
}

const initialState: UserState = {
  username: null,
  full_name: null,
  email: null,
  is_admin: false,
};

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUser: (state, action: PayloadAction<UserState>) => {
      state.username = action.payload.username;
      state.full_name = action.payload.full_name;
      state.email = action.payload.email;
      state.is_admin = action.payload.is_admin;
    },
    logout: (state) => {
      state.username = null;
      state.full_name = null;
      state.email = null;
      state.is_admin = false;
    },
  },
});

export const { setUser, logout } = userSlice.actions;

export default userSlice.reducer;
